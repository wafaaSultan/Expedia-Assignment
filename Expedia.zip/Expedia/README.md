 This project created by wafaa sultan to list group of offer, I created An API using PHP language.
