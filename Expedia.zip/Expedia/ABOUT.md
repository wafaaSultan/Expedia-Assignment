Hotel API 

  - Create Hotel Class contains objects like (HotelInfo,destination,....) to Build a good sturcture for JSON Request 
  - Then display it on web application
   
  
   


 I learned alot of things during a complish this task
  - how to read API and build API
  - understand how expedia works
  - get more knowldge about Heroku and git
  - I become familer with API
  - It make me more experienced on php and how handle JSON API through php




